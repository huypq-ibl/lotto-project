for (i = 0; i < 1000; i++) {
    console.log("test2 " + String(i))
  } 